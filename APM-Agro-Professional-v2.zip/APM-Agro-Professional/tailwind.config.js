export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: { extend: {
    colors: { darkBg: '#07110D', darkCard: '#101D16', apmGreen: '#36C878', apmGold: '#D9B45B', bnbYellow: '#F0B90B' },
    boxShadow: { glow: '0 0 40px rgba(54,200,120,.14)' }
  }},
  plugins: []
}
