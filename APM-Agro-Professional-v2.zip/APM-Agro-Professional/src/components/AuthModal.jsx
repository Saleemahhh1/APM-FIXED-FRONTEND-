import { useState } from 'react'
import { signIn, signUp, sendPasswordReset } from '../lib/auth'
export default function AuthModal({ open, onClose, onSuccess }) {
 const [mode,setMode]=useState('signin'),[form,setForm]=useState({name:'',email:'',phone:'',country:'',password:'',confirm:''}),[busy,setBusy]=useState(false),[message,setMessage]=useState(''),[error,setError]=useState('')
 if(!open)return null
 const change=e=>setForm(v=>({...v,[e.target.name]:e.target.value}))
 async function submit(e){e.preventDefault();setError('');setMessage('')
  if(mode==='signup' && form.password!==form.confirm){setError('Passwords do not match.');return}
  if(mode==='signup' && form.password.length<10){setError('Use at least 10 characters for your password.');return}
  setBusy(true);try{
   if(mode==='signup'){const d=await signUp(form);setMessage(d.session?'Account created.':'Check your email to confirm your account.')}
   else if(mode==='signin'){await signIn(form);onSuccess?.();onClose()}
   else {await sendPasswordReset(form.email);setMessage('Password reset instructions sent if the account exists.')}
  }catch(e){setError(e.message||'Authentication failed.')}finally{setBusy(false)}
 }
 return <div className="fixed inset-0 z-50 grid place-items-center bg-black/75 p-4 backdrop-blur-sm"><div className="glass w-full max-w-lg rounded-3xl p-6 sm:p-8">
  <div className="mb-6 flex items-start justify-between"><div><p className="text-xs uppercase tracking-[.22em] text-apmGold">APM-Agro account</p><h2 className="mt-2 text-2xl font-bold">{mode==='signup'?'Create your account':mode==='reset'?'Reset password':'Welcome back'}</h2><p className="mt-1 text-sm text-white/55">Your account is separate from your blockchain wallet.</p></div><button onClick={onClose} className="text-white/50">✕</button></div>
  <div className="mb-5 flex rounded-xl bg-black/25 p-1"><button onClick={()=>setMode('signin')} className={`flex-1 rounded-lg py-2 text-sm ${mode==='signin'?'bg-apmGreen text-darkBg':''}`}>Sign in</button><button onClick={()=>setMode('signup')} className={`flex-1 rounded-lg py-2 text-sm ${mode==='signup'?'bg-apmGreen text-darkBg':''}`}>Sign up</button></div>
  <form onSubmit={submit} className="space-y-3">
   {mode==='signup'&&<><input className="field" name="name" placeholder="Full name" value={form.name} onChange={change} required/><div className="grid grid-cols-2 gap-3"><input className="field" name="phone" placeholder="Phone number" value={form.phone} onChange={change}/><input className="field" name="country" placeholder="Country" value={form.country} onChange={change}/></div></>}
   <input className="field" type="email" name="email" placeholder="Email address" value={form.email} onChange={change} required/>
   {mode!=='reset'&&<><input className="field" type="password" name="password" placeholder="Password" value={form.password} onChange={change} required autoComplete={mode==='signup'?'new-password':'current-password'}/>{mode==='signup'&&<input className="field" type="password" name="confirm" placeholder="Confirm password" value={form.confirm} onChange={change} required autoComplete="new-password"/>}</>}
   {error&&<p role="alert" className="text-sm text-red-300">{error}</p>}{message&&<p role="status" className="text-sm text-apmGreen">{message}</p>}
   <button disabled={busy} className="btn-primary w-full">{busy?'Please wait…':mode==='signup'?'Create account':mode==='reset'?'Send reset email':'Sign in securely'}</button>
  </form>
  {mode==='signin'&&<button onClick={()=>setMode('reset')} className="mt-4 text-sm text-apmGold">Forgot password?</button>}
  <p className="mt-5 text-xs leading-5 text-white/40">Never share your password or recovery phrase. APM-Agro will never ask for your wallet seed phrase.</p>
 </div></div>
}
