# APM-Agro

Decentralized agriculture prediction-market frontend built with React, Vite and ethers v6.

> **Integration status:** this is a professional frontend foundation. Before production, import the exact deployed contract JSON artifacts from `src/contract/` and verify every address against BNB Testnet explorer. The three ABIs summarized in earlier project discussions were not available as complete files in this build context, so no guessed ABI is presented as production-ready.

## Quick start
1. `cp .env.example .env` and verify contract addresses.
2. `npm install`
3. `npm run dev`
4. `npm run build`

## Authentication
Email/password registration and login use Supabase Auth. Create a Supabase project, enable email authentication, then set `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`. The app does not store passwords in localStorage. Optional profile fields are stored in `profiles`; apply the SQL in `supabase/schema.sql`.

Wallet connection is separate from email authentication. A connected address is not treated as proof of a real-world identity. For wallet-based sign-in, add a server-verified SIWE/EIP-4361 nonce/signature flow before production.

## Contracts
- Network: BNB Testnet (chain ID 97)
- APM token and factory addresses are prefilled from the previously recorded deployment notes; verify them before use.
- MarketFactory and PredictionMarket call signatures recorded in project discussions: `createMarket(string,uint256,uint256)`, `getAllMarkets()`, `getUserMarkets(address)`, `resolveMarket(address,uint8)`, `placeBet(uint256,uint256)`, `claim()`, `setResult(uint8)`. YES=1 and NO=2.
- `VestingManager` must be connected only after its verified deployed address and complete ABI are added.
- Current frontend intentionally disables contract write flows until verified ABI artifacts are installed. This prevents wrong calls and misleading success states.

## Security checklist
- Never commit `.env`.
- Never expose Supabase service-role keys or wallet private keys in browser code.
- Use server-side email confirmation and password reset.
- Verify all contract addresses and ABI fragments on BscScan.
- Test allowance, stake, resolution, claim, and vesting flows on testnet.
- Obtain an independent smart-contract audit before mainnet use.

## License
MIT. See `LICENSE`.
